#include "source.h"




int encode_string(char* source, char* dest, int col_count, char pad)
{
return 0;
}


int decode_string(char* source, char* dest, int col_count)
{
return 0;
}

int encode_string_with_key(char* source, char* dest, char* key, char pad)
{

return 0;
}


int decode_string_with_key(char* source, char* dest, char* key)
{
return 0;
}


