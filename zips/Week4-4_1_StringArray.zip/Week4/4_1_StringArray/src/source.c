#include "source.h"


int locate_string(char **stringArray, int len, char * string)
{
    return -1;
}
