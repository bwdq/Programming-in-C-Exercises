
int locate_string(char **stringArray, int len, char *string);

