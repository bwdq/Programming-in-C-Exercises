#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include "hidden_text.h"

/* Exercise 1 */
uint8_t read_lsb(FILE* fp) {
    return 0; }

/* Exercise 2 */
uint8_t extract_byte(FILE* fp) {
    return 0; }


/* Exercise 3 */
uint32_t read_uint32(FILE* f) {
    return 0; }

/* Exercise 4 */
uint32_t read_pixel_offset(FILE* f) {
    return 0; }
/* Exercise 5 */
void read_msg(FILE* f) {
}
