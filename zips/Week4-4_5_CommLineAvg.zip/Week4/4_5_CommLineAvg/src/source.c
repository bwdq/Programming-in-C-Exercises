#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "source.h"

int * arg2int(int argc, const char* argv[]) {
    return NULL 
}

float arrayAvg(int size, int *array) {
    /*STUB return 0.0/0.0; */
}



