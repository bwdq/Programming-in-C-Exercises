/* Fuction signatures for prosessing string arrays and integer arrays in this task */

int * arg2int(int argc, const char* argv[]);

float arrayAvg(int size, int *array);



