int word_count(char*);
