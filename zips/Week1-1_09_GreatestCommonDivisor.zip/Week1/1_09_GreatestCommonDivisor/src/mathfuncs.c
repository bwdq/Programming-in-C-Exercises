#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mathfuncs.h"


int gcd(int a, int b)
{
	return 0; }


int gcd_iterative(int a, int b) {
	return 0; }
