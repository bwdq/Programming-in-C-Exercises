int gcd(int a, int b);
int gcd_iterative(int a, int b);
