#include <stdio.h>

void multiply_matrix(int size){
    
}
