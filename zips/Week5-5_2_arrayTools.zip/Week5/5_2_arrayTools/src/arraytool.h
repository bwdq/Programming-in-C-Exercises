#ifndef AALTO_ARRAYTOOL_H
#define AALTO_ARRAYTOOL_H

// Implement something here...


#endif
