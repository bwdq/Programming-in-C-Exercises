#include <stdio.h>
#include "source.h"

void swap(double* a, double* b){
}
