void swap(double*, double*);
