void calculate_average(void);
