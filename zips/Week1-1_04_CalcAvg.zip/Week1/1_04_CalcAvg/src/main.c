#include <stdio.h>
#include "source.h"

/* Write function calculate_average() that reads grades from the user until she enters -1. Grades are positive integers. 
 * Then function prints the average of the grades with two digits of precision. If the user enters only -1, print 0.00.*/

/* You may modify the main function as you wish. It is not tested by the tmc server*/

int main()
{
    calculate_average();
    return 0;
}
