#include <stdio.h>
#include <stdlib.h>
#include "source.h"

/* Write function print_capsLock() that reads characters from the user until ten characters have been read.
 * Then function should change every given letter to upper case character and print all read characters followed by a new line. */

/* You may modify the main function as you wish. It is not tested by the tmc server*/

int main(void) {
    
    printf("This program changes the characters you type to upper case. Please give a sequence of characters on one line.\n");
    
    print_capsLock();
    return 0;
}
