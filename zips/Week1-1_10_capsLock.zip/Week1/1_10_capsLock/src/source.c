#include <stdio.h>
#include <ctype.h>
#include "source.h"

void print_capsLock(){
}
