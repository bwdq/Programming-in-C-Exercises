int is_prime(int);
