#include <ctype.h>
#include <string.h>
#include "source.h"

void turn_around(char *p)
{
    (void) p; }
