long find_string(const char *str, const char *filename, long offset);
