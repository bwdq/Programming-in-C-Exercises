int gcd(int a, int b);
int div_fraction(int a, int c, int b, int d);
int mul_fraction(int a, int c, int b, int d);
int sub_fraction(int a, int c, int b, int d);
int add_fraction(int a, int c, int b, int d);
