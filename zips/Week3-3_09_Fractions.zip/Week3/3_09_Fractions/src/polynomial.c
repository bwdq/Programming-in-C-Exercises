#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "polynomial.h"

/* GCD (Greatest common divisor) is useful in this exercise, copy the iterative version from week1 */
int gcd(int a, int b) {
  return 0; }




int add_fraction(int a, int c, int b, int d) {
	return 0; }


int sub_fraction(int a, int c, int b, int d) {
  return 0; }


int mul_fraction(int a, int c, int b, int d) {
  return 0; }


int div_fraction(int a, int c, int b, int d) {
  return 0; }
