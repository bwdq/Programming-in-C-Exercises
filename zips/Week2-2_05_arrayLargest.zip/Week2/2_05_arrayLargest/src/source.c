#include "source.h"
#include <stdio.h>

int largest_number(int* array) {
    return 0; }
