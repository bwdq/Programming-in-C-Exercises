int largest_number(int* array);

