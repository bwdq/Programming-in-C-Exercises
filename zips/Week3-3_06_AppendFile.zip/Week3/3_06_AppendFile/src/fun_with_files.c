#include <stdio.h>
#include <string.h>
#include "fun_with_files.h"

int append_string(char *file_name) {
  return 0; }

