void saveSum(int*, int*, int*);
