int binary_to_decimal(int);
