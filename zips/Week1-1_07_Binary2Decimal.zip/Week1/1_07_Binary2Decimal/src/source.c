#include "source.h"

int binary_to_decimal(int binary) {
    
}
