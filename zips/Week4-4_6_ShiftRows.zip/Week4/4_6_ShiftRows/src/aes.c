#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include "aes.h"

const int STATE_ROWS = 4;
const int STATE_COLS = 4;
const int SBOX_ROWS = 16;
const int SBOX_COLS = 16;



void print_block(state *p)
{
return;
}

state* read_block(FILE *fp)
{
	return NULL; }

void shift_row(state *arr)
{
}

void inv_shift_row(state *arr)
{
}


