#include "source.h"
#include <stdio.h>
#include <stdlib.h>

int* dynamic_reader(int size) {
    return NULL;  // replace this }
