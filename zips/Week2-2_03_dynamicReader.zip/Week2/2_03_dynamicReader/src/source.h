int* dynamic_reader(int);
