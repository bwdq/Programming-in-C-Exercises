
void remove_substr(char *str, const char *sub);

