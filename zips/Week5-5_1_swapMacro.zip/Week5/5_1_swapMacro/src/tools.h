#ifndef TOOLS_H
#define	TOOLS_H


#endif	/* TOOLS_H */

