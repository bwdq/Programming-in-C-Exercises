int most_common_character(char*);
