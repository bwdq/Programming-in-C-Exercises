int count_alpha(const char*);
