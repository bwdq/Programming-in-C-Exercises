int line_count(char*);
