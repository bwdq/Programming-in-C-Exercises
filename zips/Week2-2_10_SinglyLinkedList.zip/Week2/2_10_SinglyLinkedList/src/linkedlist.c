#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

sList* create_sList(void) {
	return NULL; }


int insert_element_s(sList *L, snodeType *p, int value) {
	return 0; }

int delete_element_s(sList *L, snodeType *p) {
	return 0; }

sList* merge_lists(sList *L1, sList *L2) {
	return NULL; }
