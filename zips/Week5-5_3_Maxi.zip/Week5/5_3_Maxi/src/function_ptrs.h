#ifndef FUNCTIONPTRS_H
#define FUNCTIONPTRS_H

double maxi(double x, double  y, double (*fp)(double z));

#endif
