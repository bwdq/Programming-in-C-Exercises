#include <stdlib.h>
#include <stdio.h>
#include "function_ptrs.h"

double maxi(double x, double y, double (*fp)(double z)) {
    return 0; }

