#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mathfuncs.h"


double sum_of_absolutes(double x, double y)
{
	return 0; }


int sum_of_rounded(double x, double y) 
{
	return 0; }


int sum_of_characters(char a, char b)
{
	return 0; }

