double sum_of_absolutes(double x, double y);
int sum_of_rounded(double x, double y);
int sum_of_characters(char a, char b);
int gcd(int a, int b);
int gcd_iterative(int a, int b);
