#include <stdio.h>
#include "source.h"

/* Implement function print(int argc, const char* argv[]) that prints the given command line arguments. 
 * Print a new line after each argument. There are some arguments added in the makefile. 
 * If you don't change them, function should print:
 * ./main
 * first
 * second
 * third */

int main(int argc, const char* argv[]) {
    
    print(argc, argv);
    
    return 0;
}
