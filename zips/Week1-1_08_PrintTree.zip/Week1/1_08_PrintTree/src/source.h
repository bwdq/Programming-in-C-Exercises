void printTree(int);

