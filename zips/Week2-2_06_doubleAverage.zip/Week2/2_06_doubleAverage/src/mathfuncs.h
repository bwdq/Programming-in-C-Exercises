double average(double* a, int len);
