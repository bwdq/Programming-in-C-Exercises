#include "source.h"
#include <stdio.h>
#include <stdlib.h>

int *add_to_array(int *array, int size, int newInt) {
    return NULL;  // replace this }

