int* add_to_array(int*, int, int);
