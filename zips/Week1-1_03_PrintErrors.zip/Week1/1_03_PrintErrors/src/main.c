#include <stdio.h>
#include "source.h"

/* Muutetaan tätä tehtävää niin, että jos käyttäjän antama syöte on virheellinen, tulostetaan virheilmoitus stderr
 * You have already written function count_sum() that asks two integers from the user, calculates their sum and prints it in the following format: 
 * 1 + 2 = 3 
 * Copy that function and change it so that it prints an error message "error" and a newline in stderr if the user gives an incorrect input. 
 * Don't print the sum if user didn't give two integers. */

/* You may modify the main function as you wish. It is not tested by the tmc server*/

int main() {
    count_sum();
    return 0;
}
