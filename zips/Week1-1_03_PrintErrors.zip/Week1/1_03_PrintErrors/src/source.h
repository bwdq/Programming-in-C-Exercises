void count_sum(void);
