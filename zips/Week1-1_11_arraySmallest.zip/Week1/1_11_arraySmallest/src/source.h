int smallest_number(int array[], int size);

