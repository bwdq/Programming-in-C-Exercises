#include "source.h"
#include <limits.h>
#include <stdio.h>

int smallest_number(int array[], int size) {
    return 0;}
