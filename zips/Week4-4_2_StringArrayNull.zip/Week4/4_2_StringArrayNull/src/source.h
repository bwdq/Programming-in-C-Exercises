
int locate_string(char **stringArray, char *string);

