#include "source.h"


int locate_string(char **stringArray, char * string)
{
    return -1;
}
