#include <stdio.h>
#include <string.h>
#include "fun_with_files.h"

int count_characters_in_file(char *filename) {
  return 0; }
