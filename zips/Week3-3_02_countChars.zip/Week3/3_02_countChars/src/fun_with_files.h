#ifndef FUN_WITH_FILES_H
#define FUN_WITH_FILES_H

int count_characters_in_file(char *file_name);

#endif /* FUN_WITH_FILES_H */
