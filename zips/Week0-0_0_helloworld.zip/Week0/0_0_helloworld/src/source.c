#include <stdio.h>
#include "source.h"

void hello_world(void){
    printf("Hello World!\n");
}
