
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "source.h"


int read_lines(char *filename, char ***array, int size) {
    return 0; }

int shortest_string (char **array, int len)
{
return -1; 
}



int find_lexi_first (char **array, int len)
{
return -1; }
