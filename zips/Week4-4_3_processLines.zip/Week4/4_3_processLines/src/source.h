
int read_lines(char *filename, char *** array, int size);

int shortest_string (char **array, int len);

int find_lexi_first (char **array, int len);

