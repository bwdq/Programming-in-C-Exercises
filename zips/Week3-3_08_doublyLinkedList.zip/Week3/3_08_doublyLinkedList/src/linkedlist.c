#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

dList* insert_element_d(dList *L, dList *p, int value) {
	return NULL; }

int print_elements_d(dList *L) {
	return 0; }

dList* delete_element_d(dList *L, dList *p) {
	return NULL; }

int order_list_d(dList *L) {
	return 0; }


